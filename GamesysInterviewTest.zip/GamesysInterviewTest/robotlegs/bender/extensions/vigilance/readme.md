# Vigilance Extension

## Overview

The Vigilance Extension throws Errors when warnings, errors or fatal messages are logged. This keeps the good times rolling.