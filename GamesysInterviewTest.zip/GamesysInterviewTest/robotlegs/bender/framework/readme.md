# Robotlegs Framework

[Context](https://github.com/robotlegs/robotlegs-framework/blob/master/src/robotlegs/bender/framework/readme-context.md)

[Logging](https://github.com/robotlegs/robotlegs-framework/blob/master/src/robotlegs/bender/framework/readme-logging.md)

[Lifecycle](https://github.com/robotlegs/robotlegs-framework/blob/master/src/robotlegs/bender/framework/readme-lifecycle.md)

[Guards](https://github.com/robotlegs/robotlegs-framework/blob/master/src/robotlegs/bender/framework/readme-guards.md)

[Hooks](https://github.com/robotlegs/robotlegs-framework/blob/master/src/robotlegs/bender/framework/readme-hooks.md)

